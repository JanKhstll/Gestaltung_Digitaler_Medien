<?php
if (isset($_GET["page"])) { // ist der Wert verfügbar
  $page = $_GET["page"]; // wenn ja, so Variable setzen
  if (substr_count($page, '.') != 0) { // man schaut wie oft der String '.' in $page vorkommt
    echo "Falscher Parameter";
    exit();
  }
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title>Test</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  </head>
  <body>
    <a href="?page=main">Main</a>
    <a href="?page=about">About</a>
    <br/>

    <!-- an dieser Stelle wird der Inhalt von der externen Datei eingefügt -->
<?php
if (!isset($page)) { // falls kein Wert gesetzt wurde 
  $page ="main"; // "Default-Wert setzen
}

$filename = $page . ".txt";

if (file_exists($filename)) {
  include($filename);  // Dateiinhalt von der Datei $filename "einfügen" 
} else {
  // kann man sich überlegen was man macht, default-Seite anzeigen, Fehler ausgeben etc.	
  echo "Datei nicht vorhanden.";
}
?>

  </body>
</html>
