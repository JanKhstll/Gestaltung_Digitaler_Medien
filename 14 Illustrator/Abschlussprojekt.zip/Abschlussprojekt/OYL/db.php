<?php
$dbname="u23166_veranstaltung";
$dbhost="localhost";
$dbuser="u23166_janko";
$dbpass="test";
mysql_connect($dbhost,$dbuser,$dbpass);
mysql_select_db($dbname);
?>